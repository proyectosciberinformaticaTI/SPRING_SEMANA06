package com.mitocode.service;

import java.util.List;

import com.mitocode.model.Nota;

public interface INotaService {
	
	List<Nota> findAll();

	Nota create(Nota Nota);

	Nota find(Integer id);

	Nota update(Nota Nota);

	void delete(Integer id);
}
